// src/pages/Research_Pages/AI.js
import React from 'react';

const AI = () => {
    return (
        <div className="ai-page">
            <h2>AI Research</h2>
            <p>Explore our research in Artificial Intelligence...</p>
            {/* Add more content as needed */}
        </div>
    );
};

export default AI;
