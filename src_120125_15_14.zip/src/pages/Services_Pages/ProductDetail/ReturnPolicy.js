import React from "react";

const ReturnPolicy = ({ data }) => {
    return (
        <div>
            <h2>Return & Replacement Policy</h2>
            <p>{data}</p>
        </div>
    );
};

export default ReturnPolicy;
