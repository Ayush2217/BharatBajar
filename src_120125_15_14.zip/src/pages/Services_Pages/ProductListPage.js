import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom'; // Import useNavigate for navigation
import '../../styles/ProductListPage.css';
import ProductCard from '../../components/Common/ProductCard';
import ProductFilters from '../../components/Common/ProductFilters';
import Pagination from '../../components/Common/Pagination';
import axios from 'axios';
import { useCart } from "../../contexts/CartContext";

const ProductListPage = () => {
    const { categoryName, subcategoryName } = useParams(); // Get category and subcategory from URL
    const [products, setProducts] = useState([]);
    const [paginatedProducts, setPaginatedProducts] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const { addToCart } = useCart(); // Use CartContext
    const navigate = useNavigate(); // Initialize navigate

    const handleAddToCart = (product) => {
        if (product) {
            addToCart(product); // Add the specific product to the cart
            console.log(`${product.name} added to cart.`);
        } else {
            console.error("Product is not loaded yet.");
        }
    };

    const handleBuyNow = (product) => {
        console.log(`Proceeding to buy ${product.name}.`);
    };

    const handleProductClick = (productName) => {
        console.log(`Navigating to detailed view for: ${productName}`);
        navigate(`/product-details/${encodeURIComponent(productName)}`);
    };

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                setLoading(true);
                const response = await axios.get(
                    `http://127.0.0.1:8000/api/products/${subcategoryName}/`
                );
                const fetchedProducts = response.data.products || [];
                setProducts(fetchedProducts);
                paginateProducts(fetchedProducts, 1);
            } catch (err) {
                console.error('Error loading products:', err);
                setError('Failed to load products. Please try again later.');
            } finally {
                setLoading(false);
            }
        };

        fetchProducts();
    }, [categoryName, subcategoryName]);

    const paginateProducts = (allProducts, page) => {
        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        setPaginatedProducts(allProducts.slice(start, end));
    };

    const handlePageChange = (page) => {
        setCurrentPage(page);
        paginateProducts(products, page);
    };

    if (loading) {
        return <div>Loading products...</div>;
    }

    if (error) {
        return <div>{error}</div>;
    }

    return (
        <div className="product-list-page">
            <h1>
                {subcategoryName ? `${subcategoryName} in ${categoryName}` : categoryName}
            </h1>

            <div className="filters-container">
                <ProductFilters />
            </div>

            <div className="product-grid">
                {paginatedProducts.length > 0 ? (
                    paginatedProducts.map((product) => (
                        <ProductCard
                            key={product.name}
                            productName={product.name}
                            productImage={product.image}
                            productPrice={product.price}
                            productData={product} // Pass the entire product data
                            onAddToCart={() => handleAddToCart(product)} // Pass the specific product
                            onBuyNow={() => handleBuyNow(product)}
                            onClick={() => handleProductClick(product.name)} // Navigate to product details
                        />
                    ))
                ) : (
                    <p>No products available for this category.</p>
                )}
            </div>

            <Pagination
                currentPage={currentPage}
                setPage={handlePageChange}
                totalItems={products.length}
                itemsPerPage={itemsPerPage}
            />
        </div>
    );
};

export default ProductListPage;
