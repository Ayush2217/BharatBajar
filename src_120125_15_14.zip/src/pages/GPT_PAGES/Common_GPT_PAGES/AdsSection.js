// AdsSection.js
import React from 'react';
import '../../../styles/AdsSection.css';

const AdsSection = () => (
    <div className="ads-section">
        <p>ADS Similar To Main page</p>
    </div>
);

export default AdsSection;
