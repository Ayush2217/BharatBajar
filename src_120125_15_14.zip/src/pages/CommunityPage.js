// CommunityPage.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import NewDiscussionPopup from './Community_Discussion_Pages/NewDiscussionPopup'; // Import the modal component
import '../styles/CommunityPage.css';

const CommunityPage = () => {
  const navigate = useNavigate();
  const [showNewDiscussionPopup, setShowNewDiscussionPopup] = useState(false);

  // Function to handle opening the new discussion modal
  const handleNewDiscussion = () => {
    setShowNewDiscussionPopup(true); // Show the popup modal
  };

  // Function to handle creating a discussion
  const handleCreateDiscussion = (discussion) => {
    setShowNewDiscussionPopup(false); // Close the popup modal
    navigate(`/discussion/${discussion.title.replace(/\s+/g, '-').toLowerCase()}`);
  };

  return (
    <div className="community-page">
      {/* Header Section */}
      <section className="community-header">
        <h1>Welcome to the Device Mantra Community</h1>
        <p>Share your experiences, engage with others, and earn rewards!</p>
        <button className="cta-button" onClick={() => navigate('/explore')}>
          Back To Exploring Devices
        </button>

        {/* Navigation Button to Community Videos Page */}
        <button
          className="cta-button"
          onClick={() => navigate('/community-videos')}
          style={{ margin: '20px 0' }}
        >
          Go to Community Videos
        </button>
      </section>

      {/* Trending in the Community Section */}
      <section className="community-content-grid">
        <h2>Trending in the Community</h2>
        <div className="content-grid">
          <div className="content-tile">
            <h3>Unboxing Video</h3>
            <p>User: TechGuru</p>
          </div>
          <div className="content-tile">
            <h3>Review: iPhone 13</h3>
            <p>User: JaneDoe</p>
          </div>
          <div className="content-tile">
            <h3>How to Fix Screen Damage</h3>
            <p>User: FixItPro</p>
          </div>
        </div>
      </section>

      {/* Discussion Forum Section */}
      <section className="discussion-forum">
        <h2>Join the Conversation</h2>
        <p>Ask questions, share advice, and connect with other tech enthusiasts.</p>
        <div className="forum-grid">
          <div className="forum-post">
            <h4>Best tips for phone maintenance?</h4>
            <p>Posted by: GadgetLover</p>
          </div>
          <div className="forum-post">
            <h4>Need help with a battery issue</h4>
            <p>Posted by: JohnDoe</p>
          </div>
        </div>
        <button className="cta-button" onClick={() => navigate('/discussion')}>
          Join a Discussion
        </button>

        {/* New "Initiate a New Discussion" button */}
        <button
          className="cta-button"
          onClick={handleNewDiscussion}
          style={{ marginTop: '10px' }}
        >
          Initiate a New Discussion
        </button>
      </section>

      {/* New Discussion Popup Modal */}
      {showNewDiscussionPopup && (
        <NewDiscussionPopup
          onClose={() => setShowNewDiscussionPopup(false)}
          onCreateDiscussion={handleCreateDiscussion}
        />
      )}
    </div>
  );
};

export default CommunityPage;
