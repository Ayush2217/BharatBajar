import React from 'react';
import { InstantSearch, SearchBox, Hits } from 'react-instantsearch-dom';
import searchClient from '../../contexts/algoliaConfig';
//import '../../styles/SearchBar.css';

const Hit = ({ hit }) => (
    <div className="search-hit">
        <img src={hit.image_uri} alt={hit.title} className="hit-image" />
        <div className="hit-content">
            <h4>{hit.title}</h4>
            <p>{hit.description}</p>
        </div>
    </div>
);

const AlgoliaSearchBar = () => {
    return (
        <InstantSearch searchClient={searchClient} indexName="your_index_name">
            <SearchBox />
            <div className="search-hits">
                <Hits hitComponent={Hit} />
            </div>
        </InstantSearch>
    );
};

export default AlgoliaSearchBar;
