import React from 'react';
import '../styles/HomePage.css'; // Importing CSS for HomePage

const HomePage = () => {
  return (
    <div className="StyledHomePage">
      <p>Welcome to Gadget Mantra, your comprehensive solution for all electronic needs!</p>
    </div>
  );
}

export default HomePage;
