import React, { forwardRef, useState } from 'react';
import '../../styles/AuthModal.css';
import googleLogo from '../../assets/google.jpg';
import microsoftLogo from '../../assets/microsoft.png';
import appleLogo from '../../assets/apple.png';

const existingUsers = {
    emails: ['existing@example.com'],
    usernames: ['existingUser']
};

const AuthModal = forwardRef(({ isOpen, onClose }, ref) => {
    const [isLogin, setIsLogin] = useState(true);
    const [identifier, setIdentifier] = useState('');
    const [password, setPassword] = useState('');
    const [username, setUsername] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const [emailError, setEmailError] = useState('');
    const [passwordError, setPasswordError] = useState('');

    const handleIdentifierChange = (e) => {
        setIdentifier(e.target.value.trim());
    };

    const handlePasswordChange = (e) => {
        setPassword(e.target.value.trim());
    };

    const validateIdentifier = (identifier) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const usernameRegex = /^[a-zA-Z0-9]+$/;
        return emailRegex.test(identifier) || usernameRegex.test(identifier);
    };

    const validatePassword = (password) => {
        const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        return passwordRegex.test(password);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setEmailError('');
        setPasswordError('');

        let valid = true;

        if (!validateIdentifier(identifier)) {
            setEmailError('Please enter a valid email address or username.');
            valid = false;
        } else if (existingUsers.emails.includes(identifier) && isLogin) {
            setEmailError('Email already exists. Please sign up.');
            setIsLogin(false);
            valid = false;
        }

        if (!validatePassword(password)) {
            setPasswordError('Password must be at least 8 characters long and include letters, numbers, and special characters.');
            valid = false;
        }

        if (valid) {
            console.log('Form submitted:', { identifier, password, ...( !isLogin && { username, phone: phoneNumber }) });
            // Here you would typically handle the logic to authenticate the user or create a new account
        }
    };

    if (!isOpen) return null;

    return (
        <div ref={ref} className="modal">
            <div className="modal-content">
                <div className="modal-header">
                    <h2>{isLogin ? 'Welcome back' : 'Create your account'}</h2>
                    <span className="close" onClick={onClose}>&times;</span>
                </div>
                <form onSubmit={handleSubmit} className={isLogin ? 'login-form' : 'signup-form'}>
                    {!isLogin && (
                        <>
                            <div className="form-group">
                                <label htmlFor="username">Username*</label>
                                <input
                                    type="text"
                                    id="username"
                                    placeholder="Username"
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                    required={!isLogin}
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="phone">Phone Number (Optional)</label>
                                <input
                                    type="tel"
                                    id="phone"
                                    placeholder="Phone Number (optional) "
                                    value={phoneNumber}
                                    onChange={(e) => setPhoneNumber(e.target.value)}
                                />
                            </div>
                        </>
                    )}
                    <div className="form-group">
                        <label htmlFor="identifier">Email Address or Username*</label>
                        <input
                            type="text"
                            id="identifier"
                            placeholder="Email Address or Username"
                            value={identifier}
                            onChange={handleIdentifierChange}
                            required
                        />
                        {emailError && <div className="error">{emailError}</div>}
                    </div>
                    <div className="form-group">
                        <label htmlFor="password">Password*</label>
                        <input
                            type="password"
                            id="password"
                            placeholder="Password"
                            value={password}
                            onChange={handlePasswordChange}
                            required
                        />
                        {passwordError && <div className="error">{passwordError}</div>}
                    </div>
                    <button type="submit" className="continue-button">{isLogin ? 'Log In' : 'Sign Up'}</button>
                    <button onClick={() => setIsLogin(!isLogin)} className="toggle-button">
                        {isLogin ? 'Need to create an account?' : 'Already have an account? Log in'}
                    </button>
                    <div className="or-divider"><span>OR</span></div>
                    <button type="button" className="social-button google-button">
                        <img src={googleLogo} alt="Google logo" className="social-logo" /> Continue with Google
                    </button>
                    <button type="button" className="social-button microsoft-button">
                        <img src={microsoftLogo} alt="Microsoft logo" className="social-logo" /> Continue with Microsoft Account
                    </button>
                    <button type="button" className="social-button apple-button">
                        <img src={appleLogo} alt="Apple logo" className="social-logo" /> Continue with Apple
                    </button>
                </form>
            </div>
        </div>
    );
});

export default AuthModal;
