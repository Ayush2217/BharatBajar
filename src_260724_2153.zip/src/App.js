// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import GPT from './pages/GPT';
import Sales from './pages/GPT_PAGES/Sales';
import Diagnostics from './pages/GPT_PAGES/Diagnostics';
import Warranty from './pages/GPT_PAGES/Warranty';
import './styles/App.css';
import Training from './pages/GPT_PAGES/Training';
import Learning from './pages/GPT_PAGES/Learning';
import Refurbished from './pages/GPT_PAGES/Refurbished';
import Repair from './pages/Services_Pages/Repair';
import SalesPage from './pages/Services_Pages/Sales';
import Resale from './pages/Services_Pages/Resale';
import WarrantyPage from './pages/Services_Pages/Warranty';
import TrainingPage from './pages/Services_Pages/Training';
import LearningPage from './pages/Services_Pages/Learning';
import AI from './pages/Research_Pages/AI';
import Blockchain from './pages/Research_Pages/Blockchain';
import Sustainability from './pages/Research_Pages/Sustainability';
import Support from './pages/ContactUS_Pages/Support';
import ContactSales from './pages/ContactUS_Pages/ContactSales';
import Feedback from './pages/ContactUS_Pages/Feedback';
import Team from './pages/AboutUS_Pages/Team';
import Careers from './pages/AboutUS_Pages/Careers';
import Mission from './pages/AboutUS_Pages/Mission';

function App() {
  return (
    <Router>
      <div id="root">
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/gpt" element={<GPT />} />
			<Route path="/sales" element={<Sales />} />
			<Route path="/diagnostics" element={<Diagnostics />} />
			<Route path="/warranty" element={<Warranty />} />
			<Route path="/training" element={<Training />} />
			<Route path="/learning" element={<Learning />} />
			<Route path="/refurbished" element={<Refurbished />} />
            <Route path="/salespage" element={<SalesPage />} />
            <Route path="/repair" element={<Repair />} />
            <Route path="/refurbishedpage" element={<Resale />} />
            <Route path="/warrantypage" element={<WarrantyPage />} />
            <Route path="/trainingpage" element={<TrainingPage />} />
            <Route path="/learningpage" element={<LearningPage />} />
            <Route path="/ai" element={<AI />} />
            <Route path="/blockchain" element={<Blockchain />} />
            <Route path="/sustainability" element={<Sustainability />} />
			<Route path="/support" element={<Support />} />
            <Route path="/contactsales" element={<ContactSales />} />
            <Route path="/feedback" element={<Feedback />} />
			<Route path="/team" element={<Team />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/mission" element={<Mission />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
