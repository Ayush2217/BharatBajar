import React from 'react';
import { Link } from 'react-router-dom';

const GPT = () => {
    return (
        <div className="gpt-chat-page">
            <header className="gpt-header">
                <div className="gpt-logo">
                    <img src="/path/to/logo.png" alt="Logo" />
                </div>
                <div className="gpt-nav">
                    <Link to="/" className="gpt-button">Back to Main Page</Link>
                    <Link to="/gpt" className="gpt-button">Start A New Chat</Link>
                    <button className="gpt-button">See Previous Chats</button>
                </div>
            </header>
            <div className="gpt-chat-container">
                <div className="gpt-sidebar">
                    <div className="gpt-section">
                        <h3>Explore</h3>
                        <ul>
                            <li><Link to="/sales">Sales</Link></li>
                            <li><Link to="/diagnostics">Diagnostics</Link></li>
                            <li><Link to="/Warranty">Warranty</Link></li>
                            <li><Link to="/training">Training</Link></li>
                            <li><Link to="/learning">Learning</Link></li>
                            <li><Link to="/refurbished">Refurbished</Link></li>
                        </ul>
                    </div>
                </div>
                <div className="gpt-main-chat">
                    <div className="gpt-chat-header">
                        <h2>General</h2>
                    </div>
                    <div className="gpt-chat-box">
                        <div className="gpt-messages">
                            <div className="gpt-message">E-GPT Reply</div>
                        </div>
                        <div className="gpt-input-container">
                            <input type="text" placeholder="Message E-GPT" />
                            <button className="gpt-send-button">Send</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default GPT;
