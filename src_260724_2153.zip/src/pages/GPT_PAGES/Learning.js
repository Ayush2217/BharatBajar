import React, { useState } from 'react';
import '../../styles/Learning.css';
import { Link } from 'react-router-dom';

const Learning = () => {
    const [question, setQuestion] = useState('');
    const [answer, setAnswer] = useState('');

    const handleQuestionChange = (event) => {
        setQuestion(event.target.value);
    };

    const handleAskQuestion = () => {
        // Here, you would typically make an API call to get the answer from GPT
        // For this example, we'll just set a placeholder answer
        setAnswer('This is the answer from GPT.');
    };

    return (
        <div className="learning-page">
            <header className="learning-header">
                <div className="learning-logo">
                    <img src="/path/to/logo.png" alt="Logo" />
                </div>
                <div className="learning-nav">
                    <Link to="/" className="learning-button">Back to Main Page</Link>
                    <Link to="/learning" className="learning-button">Start A New Chat</Link>
                    <button className="learning-button">See Previous Chats</button>
                </div>
            </header>
            <div className="learning-container">
                <div className="learning-sidebar">
                    <div className="learning-section">
                        <h3>Explore</h3>
                        <ul>
                            <li><Link to="/gpt">General</Link></li>
                            <li><Link to="/sales">Sales</Link></li>
                            <li><Link to="/diagnostics">Diagnostics</Link></li>
                            <li><Link to="/warranty">Warranties</Link></li>
                            <li><Link to="/training">Training</Link></li>
                            <li><Link to="/refurbished">Refurbished</Link></li>
                        </ul>
                    </div>
                </div>
                <div className="learning-main">
                    <div className="learning-main-header">
                        <h2>Learning</h2>
                    </div>
                    <div className="learning-content">
                        {/* Add any specific content for learning here */}
                    </div>
                    <div className="learning-input-section">
                        <input
                            type="text"
                            placeholder="Ask E-GPT to help with your device learning"
                            value={question}
                            onChange={handleQuestionChange}
                            className="learning-input"
                        />
                        <button onClick={handleAskQuestion} className="learning-send-button">Send</button>
                    </div>
                    <div className="learning-answer-section">
                        {answer && (
                            <div className="learning-answer">
                                <p>{answer}</p>
                            </div>
                        )}
                    </div>
                    <div className="learning-footer">
                        <p>Ask E-GPT to help with your device learning</p>
                    </div>
                </div>
                <div className="learning-ads">
                    <p>ADS Similar To Main page</p>
                </div>
            </div>
        </div>
    );
};

export default Learning;
