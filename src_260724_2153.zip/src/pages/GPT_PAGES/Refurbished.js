import React, { useState } from 'react';
import '../../styles/Refurbished.css';
import { Link } from 'react-router-dom';

const Refurbished = () => {
    const [question, setQuestion] = useState('');
    const [answer, setAnswer] = useState('');

    const handleQuestionChange = (event) => {
        setQuestion(event.target.value);
    };

    const handleAskQuestion = () => {
        // Here, you would typically make an API call to get the answer from GPT
        // For this example, we'll just set a placeholder answer
        setAnswer('This is the answer from GPT.');
    };

    return (
        <div className="refurbished-page">
            <header className="refurbished-header">
                <div className="refurbished-logo">
                    <img src="/path/to/logo.png" alt="Logo" />
                </div>
                <div className="refurbished-nav">
                    <Link to="/" className="refurbished-button">Back to Main Page</Link>
                    <Link to="/refurbished" className="refurbished-button">Start A New Chat</Link>
                    <button className="refurbished-button">See Previous Chats</button>
                </div>
            </header>
            <div className="refurbished-container">
                <div className="refurbished-sidebar">
                    <div className="refurbished-section">
                        <h3>Explore</h3>
                        <ul>
                            <li><Link to="/gpt">General</Link></li>
                            <li><Link to="/sales">Sales</Link></li>
                            <li><Link to="/diagnostics">Diagnostics</Link></li>
                            <li><Link to="/warranty">Warranties</Link></li>
                            <li><Link to="/training">Training</Link></li>
                            <li><Link to="/learning">Learning</Link></li>
                        </ul>
                    </div>
                </div>
                <div className="refurbished-main">
                    <div className="refurbished-main-header">
                        <h2>Refurbished</h2>
                    </div>
                    <div className="refurbished-device-comparison">
                        <div className="refurbished-device">
                            <h3>Device X (type your device name)</h3>
                            <div className="refurbished-device-details">
                                <div className="refurbished-device-info">
                                    <p>Device</p>
                                </div>
                                <div className="refurbished-device-info">
                                    <p>Manufacturer</p>
                                </div>
                                <div className="refurbished-device-info">
                                    <p>Series</p>
                                </div>
                                <div className="refurbished-device-info">
                                    <p>Model</p>
                                </div>
                            </div>
                        </div>
                        <div className="refurbished-add-more">
                            <p>Add More Devices to compare</p>
                        </div>
                        <div className="refurbished-device">
                            <h3>Device X (type your device name)</h3>
                            <div className="refurbished-device-details">
                                <div className="refurbished-device-info">
                                    <p>Device</p>
                                </div>
                                <div className="refurbished-device-info">
                                    <p>Manufacturer</p>
                                </div>
                                <div className="refurbished-device-info">
                                    <p>Series</p>
                                </div>
                                <div className="refurbished-device-info">
                                    <p>Model</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="refurbished-input-section">
                        <input
                            type="text"
                            placeholder="Ask E-GPT to help sell your device or buy a refurbished device"
                            value={question}
                            onChange={handleQuestionChange}
                            className="refurbished-input"
                        />
                        <button onClick={handleAskQuestion} className="refurbished-send-button">Send</button>
                    </div>
                    <div className="refurbished-answer-section">
                        {answer && (
                            <div className="refurbished-answer">
                                <p>{answer}</p>
                            </div>
                        )}
                    </div>
                    <div className="refurbished-footer">
                        <p>Ask E-GPT to help sell your device or buy a refurbished device</p>
                    </div>
                </div>
                <div className="refurbished-ads">
                    <p>ADS Similar To Main page</p>
                </div>
            </div>
        </div>
    );
};

export default Refurbished;
