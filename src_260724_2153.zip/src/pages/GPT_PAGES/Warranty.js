import React, { useState } from 'react';
import '../../styles/Warranty.css';
import { Link } from 'react-router-dom';

const Warranty = () => {
    const [question, setQuestion] = useState('');
    const [answer, setAnswer] = useState('');

    const handleQuestionChange = (event) => {
        setQuestion(event.target.value);
    };

    const handleAskQuestion = () => {
        // Here, you would typically make an API call to get the answer from GPT
        // For this example, we'll just set a placeholder answer
        setAnswer('This is the answer from GPT.');
    };

    return (
        <div className="warranty-page">
            <header className="warranty-header">
                <div className="warranty-logo">
                    <img src="/path/to/logo.png" alt="Logo" />
                </div>
                <div className="warranty-nav">
                    <Link to="/" className="warranty-button">Back to Main Page</Link>
                    <Link to="/warranty" className="warranty-button">Start A New Chat</Link>
                    <button className="warranty-button">See Previous Chats</button>
                </div>
            </header>
            <div className="warranty-container">
                <div className="warranty-sidebar">
                    <div className="warranty-section">
                        <h3>Explore</h3>
                        <ul>
                            <li><Link to="/gpt">General</Link></li>
                            <li><Link to="/sales">Sales</Link></li>
                            <li><Link to="/diagnostics">Diagnostics</Link></li>
                            <li><Link to="/training">Training</Link></li>
                            <li><Link to="/learning">Learning</Link></li>
                            <li><Link to="/refurbished">Refurbished</Link></li>
                        </ul>
                    </div>
                </div>
                <div className="warranty-main">
                    <div className="warranty-main-header">
                        <h2>Claim Warranty</h2>
                    </div>
                    <div className="warranty-device-comparison">
                        <div className="warranty-device">
                            <h3>Device X (Type your device name)</h3>
                            <div className="warranty-device-details">
                                <div className="warranty-device-info">
                                    <p>Device Type</p>
                                </div>
                                <div className="warranty-device-info">
                                    <p>Manufacturer</p>
                                </div>
                                <div className="warranty-device-info">
                                    <p>Series</p>
                                </div>
                                <div className="warranty-device-info">
                                    <p>Model</p>
                                </div>
                            </div>
                        </div>
                        <div className="warranty-add-more">
                            <p>Claim Warranty of more devices</p>
                        </div>
                        <div className="warranty-device">
                            <h3>Device X (Type your device name)</h3>
                            <div className="warranty-device-details">
                                <div className="warranty-device-info">
                                    <p>Device Type</p>
                                </div>
                                <div className="warranty-device-info">
                                    <p>Manufacturer</p>
                                </div>
                                <div className="warranty-device-info">
                                    <p>Series</p>
                                </div>
                                <div className="warranty-device-info">
                                    <p>Model</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="warranty-input-section">
                        <input
                            type="text"
                            placeholder="Ask E-GPT to help with your device warranty"
                            value={question}
                            onChange={handleQuestionChange}
                            className="warranty-input"
                        />
                        <button onClick={handleAskQuestion} className="warranty-send-button">Send</button>
                    </div>
                    <div className="warranty-answer-section">
                        {answer && (
                            <div className="warranty-answer">
                                <p>{answer}</p>
                            </div>
                        )}
                    </div>
                    <div className="warranty-footer">
                        <p>Ask E-GPT to help with your device warranty</p>
                    </div>
                </div>
                <div className="warranty-ads">
                    <p>ADS Similar To Main page</p>
                </div>
            </div>
        </div>
    );
};

export default Warranty;
