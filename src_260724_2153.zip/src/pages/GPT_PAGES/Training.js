import React, { useState } from 'react';
import '../../styles/Training.css';
import { Link } from 'react-router-dom';

const Training = () => {
    const [question, setQuestion] = useState('');
    const [answer, setAnswer] = useState('');

    const handleQuestionChange = (event) => {
        setQuestion(event.target.value);
    };

    const handleAskQuestion = () => {
        // Here, you would typically make an API call to get the answer from GPT
        // For this example, we'll just set a placeholder answer
        setAnswer('This is the answer from GPT.');
    };

    return (
        <div className="training-page">
            <header className="training-header">
                <div className="training-logo">
                    <img src="/path/to/logo.png" alt="Logo" />
                </div>
                <div className="training-nav">
                    <Link to="/" className="training-button">Back to Main Page</Link>
                    <Link to="/training" className="training-button">Start A New Chat</Link>
                    <button className="training-button">See Previous Chats</button>
                </div>
            </header>
            <div className="training-container">
                <div className="training-sidebar">
                    <div className="training-section">
                        <h3>Explore</h3>
                        <ul>
                            <li><Link to="/gpt">General</Link></li>
                            <li><Link to="/sales">Sales</Link></li>
                            <li><Link to="/diagnostics">Diagnostics</Link></li>
                            <li><Link to="/warranty">Warranties</Link></li>
                            <li><Link to="/learning">Learning</Link></li>
                            <li><Link to="/refurbished">Refurbished</Link></li>
                        </ul>
                    </div>
                </div>
                <div className="training-main">
                    <div className="training-main-header">
                        <h2>Training</h2>
                    </div>
                    <div className="training-content">
                        {/* Add any specific content for training here */}
                    </div>
                    <div className="training-input-section">
                        <input
                            type="text"
                            placeholder="Ask E-GPT to help with your device training"
                            value={question}
                            onChange={handleQuestionChange}
                            className="training-input"
                        />
                        <button onClick={handleAskQuestion} className="training-send-button">Send</button>
                    </div>
                    <div className="training-answer-section">
                        {answer && (
                            <div className="training-answer">
                                <p>{answer}</p>
                            </div>
                        )}
                    </div>
                    <div className="training-footer">
                        <p>Ask E-GPT to help with your device training</p>
                    </div>
                </div>
                <div className="training-ads">
                    <p>ADS Similar To Main page</p>
                </div>
            </div>
        </div>
    );
};

export default Training;
