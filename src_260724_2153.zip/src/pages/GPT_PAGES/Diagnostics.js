import React, { useState } from 'react';
import '../../styles/Diagnostics.css';
import { Link } from 'react-router-dom';

const Diagnostics = () => {
    const [question, setQuestion] = useState('');
    const [answer, setAnswer] = useState('');

    const handleQuestionChange = (event) => {
        setQuestion(event.target.value);
    };

    const handleAskQuestion = () => {
        // Here, you would typically make an API call to get the answer from GPT
        // For this example, we'll just set a placeholder answer
        setAnswer('This is the answer from GPT.');
    };

    return (
        <div className="diagnostics-page">
            <header className="diagnostics-header">
                <div className="diagnostics-logo">
                    <img src="/path/to/logo.png" alt="Logo" />
                </div>
                <div className="diagnostics-nav">
                    <Link to="/" className="diagnostics-button">Back to Main Page</Link>
                    <Link to="/diagnostics" className="diagnostics-button">Start A New Chat</Link>
                    <button className="diagnostics-button">See Previous Chats</button>
                </div>
            </header>
            <div className="diagnostics-container">
                <div className="diagnostics-sidebar">
                    <div className="diagnostics-section">
                        <h3>Explore</h3>
                        <ul>
                            <li><Link to="/gpt">General</Link></li>
                            <li><Link to="/sales">Sales</Link></li>
                            <li><Link to="/warranty">Warranty</Link></li>
                            <li><Link to="/training">Training</Link></li>
                            <li><Link to="/learning">Learning</Link></li>
                            <li><Link to="/refurbished">Refurbished</Link></li>
                        </ul>
                    </div>
                </div>
                <div className="diagnostics-main">
                    <div className="diagnostics-header">
                        <h2>Diagnostics</h2>
                    </div>
                    <div className="diagnostics-device-comparison">
                        <div className="diagnostics-device">
                            <h3>Device X (Type your device name)</h3>
                            <div className="diagnostics-device-details">
                                <div className="diagnostics-device-info">
                                    <p>Device Type</p>
                                </div>
                                <div className="diagnostics-device-info">
                                    <p>Manufacturer</p>
                                </div>
                                <div className="diagnostics-device-info">
                                    <p>Series</p>
                                </div>
                                <div className="diagnostics-device-info">
                                    <p>Model</p>
                                </div>
                            </div>
                        </div>
                        <div className="diagnostics-add-more">
                            <p>Get more Devices Diagnosed</p>
                        </div>
                        <div className="diagnostics-device">
                            <h3>Device X (Type your device name)</h3>
                            <div className="diagnostics-device-details">
                                <div className="diagnostics-device-info">
                                    <p>Device Type</p>
                                </div>
                                <div className="diagnostics-device-info">
                                    <p>Manufacturer</p>
                                </div>
                                <div className="diagnostics-device-info">
                                    <p>Series</p>
                                </div>
                                <div className="diagnostics-device-info">
                                    <p>Model</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="diagnostics-input-section">
                        <input
                            type="text"
                            placeholder="Ask E-GPT to help diagnose your device"
                            value={question}
                            onChange={handleQuestionChange}
                            className="diagnostics-input"
                        />
                        <button onClick={handleAskQuestion} className="diagnostics-send-button">Send</button>
                    </div>
                    <div className="diagnostics-answer-section">
                        {answer && (
                            <div className="diagnostics-answer">
                                <p>{answer}</p>
                            </div>
                        )}
                    </div>
                    <div className="diagnostics-footer">
                        <p>Ask E-GPT to help diagnose your device</p>
                    </div>
                </div>
                <div className="diagnostics-ads">
                    <p>ADS Similar To Main page</p>
                </div>
            </div>
        </div>
    );
};

export default Diagnostics;
