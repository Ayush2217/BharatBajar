// src/pages/Sales.js
import React from 'react';

const SalesPage = () => {
    return (
        <div className="sales-page">
            <h2>Sales</h2>
            <p>Explore our curated selection of cutting-edge electronic devices.</p>
            {/* Add more content as needed */}
        </div>
    );
};

export default SalesPage;
