// src/components/Header.js
import React, { useState, useEffect, useRef } from 'react';
import '../styles/Header.css'; // Ensure this path is correct
import AuthModal from './auth/AuthModal';
import { Link } from 'react-router-dom';
import searchIcon from '../assets/Logo.png'; // Ensure this is the correct path to the logo

const Header = ({ onLogout }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isSearchOpen, setIsSearchOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [dropdownOpen, setDropdownOpen] = useState({ services: false, research: false, contact: false, aboutUs: false });
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [username, setUsername] = useState('');

    const searchRef = useRef(null);

    useEffect(() => {
        const token = localStorage.getItem('token');
        const username = localStorage.getItem('username');
        if (token && username) {
            setIsLoggedIn(true);
            setUsername(username);
        }
    }, []);

    const handleLogout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('username');
        setIsLoggedIn(false);
        setUsername('');
        onLogout(); // Call the logout function passed as a prop
    };

    const toggleModal = () => {
        setIsModalOpen(!isModalOpen);
    };

    const toggleSearch = () => {
        setIsSearchOpen(!isSearchOpen);
    };

    const handleSearchChange = (e) => {
        setSearchQuery(e.target.value);
    };

    const handleSearchSubmit = (e) => {
        e.preventDefault();
        console.log('Search query:', searchQuery);
        // Implement search functionality here
    };

    const toggleDropdown = (menu) => {
        setDropdownOpen(prevState => ({
            ...prevState,
            [menu]: !prevState[menu]
        }));
    };

    const closeDropdowns = () => {
        setDropdownOpen({ services: false, research: false, contact: false, aboutUs: false });
    };

    return (
        <header className="header">
            <div className="logo-container" ref={searchRef}>
                <img src={searchIcon} alt="Search" className="search-icon" onClick={toggleSearch} />
                <div className="logo">
                    <Link to="/" className="logo-button">{isLoggedIn ? `Welcome, ${username} to Device Mantra` : 'Device Mantra'}</Link>
                </div>
                {isSearchOpen && (
                    <form className="search-form" onSubmit={handleSearchSubmit}>
                        <input
                            type="text"
                            className="search-input"
                            value={searchQuery}
                            onChange={handleSearchChange}
                            placeholder="Search..."
                        />
                    </form>
                )}
            </div>
            <div className="nav-container">
                <nav className="nav">
                    <div className="nav-item" onMouseEnter={() => toggleDropdown('services')} onMouseLeave={closeDropdowns}>
                        <a href="#services">Services</a>
                        {dropdownOpen.services && (
                            <ul className="dropdown">
                                <li><Link to="/salespage">Sales</Link></li>
                                <li><Link to="/repair">Repair</Link></li>
                                <li><Link to="/refurbishedpage">Resale</Link></li>
                                <li><Link to="/warrantypage">Warranty</Link></li>
                                <li><Link to="/trainingpage">Training</Link></li>
                                <li><Link to="/learningpage">Learning</Link></li>
                            </ul>
                        )}
                    </div>
                    <div className="nav-item" onMouseEnter={() => toggleDropdown('research')} onMouseLeave={closeDropdowns}>
                        <a href="#research">Research</a>
                        {dropdownOpen.research && (
                            <ul className="dropdown">
                                <li><Link to="/ai">AI</Link></li>
                                <li><Link to="/blockchain">Blockchain</Link></li>
                                <li><Link to="/sustainability">Sustainability</Link></li>
                            </ul>
                        )}
                    </div>
                    <div className="nav-item" onMouseEnter={() => toggleDropdown('contact')} onMouseLeave={closeDropdowns}>
                        <a href="#contact">Contact Us</a>
                        {dropdownOpen.contact && (
                            <ul className="dropdown">
                                <li><Link to="/support">Support</Link></li>
                                <li><Link to="/contactsales">Sales</Link></li>
                                <li><Link to="/feedback">Feedback</Link></li>
                            </ul>
                        )}
                    </div>
                    <div className="nav-item" onMouseEnter={() => toggleDropdown('aboutUs')} onMouseLeave={closeDropdowns}>
                        <a href="#about-us">About Us</a>
                        {dropdownOpen.aboutUs && (
                            <ul className="dropdown">
                                <li><Link to="/team">Team</Link></li>
                                <li><Link to="/careers">Careers</Link></li>
                                <li><Link to="/mission">Mission</Link></li>
                            </ul>
                        )}
                    </div>
                </nav>
            </div>
            <div className="login-container">
                {isLoggedIn ? (
                    <button className="login-button" onClick={handleLogout}>Logout</button>
                ) : (
                    <button className="login-button" onClick={toggleModal}>Login</button>
                )}
            </div>
            <AuthModal isOpen={isModalOpen} onClose={toggleModal} setIsLoggedIn={setIsLoggedIn} setUsername={setUsername} />
        </header>
    );
};

export default Header;
