// src/pages/ContactUS_Pages/ContactSales.js
import React from 'react';

const ContactSales = () => {
    return (
        <div className="sales-page">
            <h2>Sales</h2>
            <p>Contact our sales team at sales@devicemantra.com...</p>
            {/* Add more content as needed */}
        </div>
    );
};

export default ContactSales;
