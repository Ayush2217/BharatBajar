const searchProductsAndServices = (query, data) => {
    if (!data || !Array.isArray(data)) {
        console.error("Invalid or undefined data passed to search function.");
        return { results: [], message: "Invalid data or products unavailable." };
    }

    const lowerCaseQuery = query.toLowerCase();
    const filteredResults = data.filter((item) =>
        item.name.toLowerCase().includes(lowerCaseQuery) ||
        (item.description && item.description.toLowerCase().includes(lowerCaseQuery))
    );

    if (filteredResults.length === 0) {
        return { results: [], message: "Product doesn't exist." };
    }

    return { results: filteredResults, message: null }; // No error message when results are found
};

export default searchProductsAndServices;
