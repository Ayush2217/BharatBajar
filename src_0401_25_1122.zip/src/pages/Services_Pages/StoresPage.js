import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../styles/StoresPage.css';
import SectionHeader from '../../components/Common/SectionHeader';
import SalesHeader from '../../components/Common/SalesHeader';

const StoresPage = () => {
    const [stores, setStores] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    const handleViewChange = (newView) => {
        if (newView === 'stores') {
            navigate('/stores');
        } else {
            navigate('/salespage');
        }
    };
    // Default dummy stores
    const dummyStores = [
        {
            id: 1,
            name: 'Electro World',
            address: '123 Electronics St, City Center',
            image: 'https://via.placeholder.com/250',
        },
        {
            id: 2,
            name: 'Tech Haven',
            address: '456 Technology Blvd, Downtown',
            image: 'https://via.placeholder.com/250',
        },
        {
            id: 3,
            name: 'Gadget Galaxy',
            address: '789 Gadget Ave, Uptown',
            image: 'https://via.placeholder.com/250',
        },
    ];

    useEffect(() => {
        const fetchStores = async () => {
            try {
                const response = await axios.get('http://127.0.0.1:8000/api/stores/');
                setStores(response.data.stores || dummyStores);
            } catch (err) {
                console.error('Error fetching stores:', err);
                setStores(dummyStores); // Fallback to dummy stores
            } finally {
                setLoading(false);
            }
        };

        fetchStores();
    }, []);

    const handleStoreClick = (storeId) => {
		navigate(`/store/${storeId}`, { state: { fromStoresPage: true } }); // Pass state to StoreDetailsPage
	};


    if (loading) {
        return <div className="loading-message">Loading...</div>;
    }

    return (
        <div className="stores-page">
            <SalesHeader onViewChange={handleViewChange} />
            <SectionHeader title="Explore Local Stores Near You" />
            <div className="stores-container">
                {stores.map((store) => (
                    <div
                        key={store.id}
                        className="store-card"
                        onClick={() => handleStoreClick(store.id)}
                    >
                        <img src={store.image} alt={store.name} className="store-image" />
                        <h3>{store.name}</h3>
                        <p>{store.address}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default StoresPage;
