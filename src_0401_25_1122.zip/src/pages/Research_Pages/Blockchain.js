// src/pages/Research_Pages/Blockchain.js
import React from 'react';

const Blockchain = () => {
    return (
        <div className="blockchain-page">
            <h2>Blockchain Research</h2>
            <p>Explore our research in Blockchain technology...</p>
            {/* Add more content as needed */}
        </div>
    );
};

export default Blockchain;
