// src/pages/AboutUS_Pages/Team.js
import React from 'react';

const Team = () => {
    return (
        <div className="team-page">
            <h2>Our Team</h2>
            <p>Meet our dedicated team members...</p>
            {/* Add more content as needed */}
        </div>
    );
};

export default Team;
