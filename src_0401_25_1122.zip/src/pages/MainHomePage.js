import React from 'react';
import '../styles/MainHomePage.css'; // Ensure you create corresponding CSS

const MainHomePage = () => {
  return (
    <div className="main-homepage">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-content">
          <h1>Welcome to Device Mantra</h1>
          <p>Explore devices, share your experience, and engage with the community.</p>
          <div className="hero-buttons">
            <button className="cta-button" onClick={() => window.location.href = '/explore'}>
              Explore DM
            </button>
            <button className="cta-button secondary" onClick={() => window.location.href = '/community'}>
              DM Community
            </button>
          </div>
        </div>
      </section>

      {/* Product Carousel */}
      <section className="product-carousel">
        <h2>Featured Devices</h2>
        <div className="carousel-container">
          {/* Carousel Items */}
          <div className="carousel-item">Product 1</div>
          <div className="carousel-item">Product 2</div>
          <div className="carousel-item">Product 3</div>
        </div>
      </section>

      {/* Community Section */}
      <section className="community-content">
        <h2>Trending in the Community</h2>
        <div className="content-grid">
          <div className="content-tile">User Review</div>
          <div className="content-tile">Unboxing Video</div>
        </div>
      </section>

      {/* Sustainability Section */}
      <section className="sustainability">
        <h2>Our Commitment to Sustainability</h2>
        <p>See how Device Mantra helps reduce electronic waste and promote eco-friendly solutions.</p>
      </section>

      {/* Testimonial Section */}
      <section className="testimonials">
        <h2>What Our Users Say</h2>
        <div className="testimonial-carousel">
          <div className="testimonial-item">"Amazing service!" - User A</div>
          <div className="testimonial-item">"Great device options!" - User B</div>
        </div>
      </section>
    </div>
  );
};

export default MainHomePage;
