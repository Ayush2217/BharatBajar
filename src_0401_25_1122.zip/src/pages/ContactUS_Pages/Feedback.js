// src/pages/ContactUS_Pages/Feedback.js
import React from 'react';

const Feedback = () => {
    return (
        <div className="feedback-page">
            <h2>Feedback</h2>
            <p>Provide your feedback at feedback@devicemantra.com...</p>
            {/* Add more content as needed */}
        </div>
    );
};

export default Feedback;
