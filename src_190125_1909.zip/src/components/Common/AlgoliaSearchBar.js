import React, { useEffect, useRef } from "react";
import algoliasearch from "algoliasearch/lite";
import instantsearch from "instantsearch.js";
import { searchBox, hits, configure } from "instantsearch.js/es/widgets";
import "instantsearch.css/themes/reset.css";
import "../../styles/AlgoliaSearchBar.css";

const AlgoliaSearchBar = () => {
  const searchContainerRef = useRef(null);
  const hitsContainerRef = useRef(null);

  useEffect(() => {
    const searchClient = algoliasearch(
      "8MRLOZ7A26", // Your Algolia App ID
      "489c1269a1685a0990ecf6569113b29c" // Your Algolia API Key
    );

    // Wait until both containers are rendered before initializing InstantSearch
    if (searchContainerRef.current && hitsContainerRef.current) {
      const search = instantsearch({
        indexName: "mobile_device1", // Your Algolia Index Name
        searchClient,
      });

      search.addWidgets([
        searchBox({
          container: searchContainerRef.current, // Reference to the searchbox container
          placeholder: "Search for products or services...",
          showReset: true,
          showSubmit: false,
          cssClasses: {
            input: "search-input",
          },
        }),
        hits({
          container: hitsContainerRef.current, // Reference to the hits container
          templates: {
            empty: `
              <div class="no-results">No results found for "<strong>{{query}}</strong>"</div>
            `,
            item: (hit) => `
              <div class="search-suggestion" onclick="window.location='/product-details/${encodeURIComponent(
                hit.title
              )}'">
                <img src="${hit.image_uri || 'https://via.placeholder.com/50'}" alt="${hit.title}" />
                <div class="suggestion-details">
                  <p class="suggestion-title">${hit.title}</p>
                  <p class="suggestion-brand">${hit.brand || "No brand"}</p>
                </div>
              </div>
            `,
          },
        }),
        configure({
          hitsPerPage: 8,
        }),
      ]);

      search.start();
    }
  }, []);

  return (
    <div className="search-container">
      <div ref={searchContainerRef} id="searchbox" className="searchbox"></div>
      <div ref={hitsContainerRef} id="hits" className="search-dropdown"></div>
    </div>
  );
};

export default AlgoliaSearchBar;
