import React from "react";

const DeliveryOptions = ({ data }) => {
    return (
        <div>
            <h2>Delivery Options</h2>
            <p>{data}</p>
        </div>
    );
};

export default DeliveryOptions;
