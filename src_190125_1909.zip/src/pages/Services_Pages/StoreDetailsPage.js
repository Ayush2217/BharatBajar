import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import SalesHeader from '../../components/Common/SalesHeader';
import SalesHeroSection from '../../components/Common/SalesHeroSection';
import SectionHeader from '../../components/Common/SectionHeader';
import '../../styles/SalesPage.css';

const StoreDetailsPage = () => {
    const navigate = useNavigate();
    const [categories, setCategories] = useState([]); // Category data
    const [activeCategory, setActiveCategory] = useState(''); // Active category
    const [loading, setLoading] = useState(true); // Loading state
    const [error, setError] = useState(null); // Error state
	 const handleViewChange = (newView) => {
        if (newView === 'stores') {
            navigate('/stores');
        } else {
            navigate('/salespage');
        }
    };
    useEffect(() => {
        const fetchData = async () => {
            try {
                // Use the same APIs as SalesPage
                const [categoriesResponse] = await Promise.all([
                    axios.get('http://127.0.0.1:8000/api/categories/'),
                ]);

                const fetchedCategories = categoriesResponse.data.categories || [];
                setCategories(fetchedCategories);
                setActiveCategory(fetchedCategories[0]?.title || ''); // Set the first category as active
            } catch (err) {
                console.error('Error fetching categories:', err);
                setError('Failed to load categories. Please try again later.');
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    const handleCategoryClick = (categoryName, subcategoryName) => {
        if (subcategoryName) {
            navigate(`/category/${categoryName.toLowerCase()}/${subcategoryName.toLowerCase()}`);
        } else {
            navigate(`/category/${categoryName.toLowerCase()}`);
        }
    };

    if (loading) {
        return <div className="loading-message">Loading...</div>;
    }

    if (error) {
        return <div className="error-message">{error}</div>;
    }

    return (
        <div className="store-details-page">
            <SalesHeader onViewChange={handleViewChange} />

            <SectionHeader title="Explore Categories in This Store" />

            {/* Categories Tabs */}
            <div className="categories-tabs">
                {categories.length > 0 ? (
                    categories.map((category) => (
                        <button
                            key={category.title}
                            className={`tab-button ${activeCategory === category.title ? 'active-tab' : ''}`}
                            onClick={() => setActiveCategory(category.title)}
                        >
                            {category.title}
                        </button>
                    ))
                ) : (
                    <p>No categories available.</p>
                )}
            </div>

            {/* Subcategories */}
            <div className="subcategories-container">
                {categories
                    .find((category) => category.title === activeCategory)
                    ?.subcategories?.map((subcategory) => (
                        <div key={subcategory} className="subcategory-card">
                            <button
                                onClick={() => handleCategoryClick(activeCategory, subcategory)}
                                className="subcategory-button"
                            >
                                {subcategory}
                            </button>
                        </div>
                    )) || <p>No subcategories available.</p>}
            </div>

            <div style={{ marginBottom: "60px" }}>
				<SalesHeroSection />
			</div>

        </div>
    );
};

export default StoreDetailsPage;
