// src/pages/ContactUS_Pages/Support.js
import React from 'react';

const Support = () => {
    return (
        <div className="support-page">
            <h2>Support</h2>
            <p>Contact our support team at support@devicemantra.com...</p>
            {/* Add more content as needed */}
        </div>
    );
};

export default Support;
