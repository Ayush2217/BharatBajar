import React, { useState } from 'react';
import '../../styles/AuthForm.css'; // Ensure the CSS is properly linked
import axios from 'axios';

function AuthForm() {
    // Toggle state between login and signup
    const [isLogin, setIsLogin] = useState(true);
    // State for user credentials
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [username, setUsername] = useState(''); // Only necessary for signup

    const handleLogin = () => {
        axios.post('http://127.0.0.1:8000/users/login/', { email, password })
            .then(response => {
                console.log('Login successful', response.data);
                localStorage.setItem('token', response.data.token);
            })
            .catch(error => {
                console.error('Login failed:', error);
            });
    }

    const handleSignUp = () => {
        axios.post('http://127.0.0.1:8000/users/login/', { email, password })
            .then(response => {
                console.log('Login successful', response.data);
                localStorage.setItem('token', response.data.token);
            })
            .catch(error => {
                console.error('Login failed:', error);
            });
    }

    // Handle form submission
    const handleSubmit = (event) => {
        event.preventDefault();
        const action = isLogin ? 'Login' : 'SignUp';
        const userDetails = { email, password, ...( !isLogin && { username }) };
        console.log(action + ':', userDetails);
        // Here you would typically handle the logic to authenticate the user or create a new account
    };

    // Function to toggle between Login and SignUp mode
    const toggleMode = () => {
        setIsLogin(!isLogin); // Toggle the state to switch modes
    };

    return (
        <div className="auth-container">
            <h2>{isLogin ? 'Login' : 'SignUp'}</h2>
            <form onSubmit={handleSubmit}>
                {!isLogin && (
                    <div className="form-group">
                        <label htmlFor="username" className="label">Username</label>
                        <input
                            type="text"
                            id="username"
                            className="input"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            required={!isLogin}
                        />
                    </div>
                )}
                <div className="form-group">
                    <label htmlFor="email" className="label">Email</label>
                    <input
                        type="email"
                        id="email"
                        className="input"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password" className="label">Password</label>
                    <input
                        type="password"
                        id="password"
                        className="input"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <button type="submit" className="button">{isLogin ? 'Log In' : 'Sign Up'}</button>
                <button type="submit" className="button" onClick={isLogin ? handleLogin : handleSignUp}>{isLogin ? 'Log In' : 'Sign Up'}</button>
            </form>
            <button onClick={toggleMode} className="toggle-button">
                {isLogin ? 'Need to create an account?' : 'Already have an account?'}
            </button>
        </div>
    );
}

export default AuthForm;
