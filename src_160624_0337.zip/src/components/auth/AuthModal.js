import React, { forwardRef, useState } from 'react';
import '../../styles/AuthModal.css';
import googleLogo from '../../assets/google.jpg';
import microsoftLogo from '../../assets/microsoft.png';
import appleLogo from '../../assets/apple.png';

const existingUsers = {
    emails: ['existing@example.com'],
    usernames: ['existingUser']
};

const AuthModal = forwardRef(({ isOpen, onClose }, ref) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [emailError, setEmailError] = useState('');
    const [passwordError, setPasswordError] = useState('');
    const [isLogin, setIsLogin] = useState(true); // State to toggle between login and signup

    const handleEmailChange = (e) => {
        setEmail(e.target.value.trim());
    };

    const handlePasswordChange = (e) => {
        setPassword(e.target.value.trim());
    };

    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

    const validatePassword = (password) => {
        const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        return passwordRegex.test(password);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setEmailError('');
        setPasswordError('');

        let valid = true;

        if (!validateEmail(email)) {
            setEmailError('Please enter a valid email address.');
            valid = false;
        } else if (existingUsers.emails.includes(email)) {
            setEmailError('Email already exists. Please sign up.');
            setIsLogin(false);
            valid = false;
        }

        if (!validatePassword(password)) {
            setPasswordError('Password must be at least 8 characters long and include letters, numbers, and special characters.');
            valid = false;
        }

        if (valid) {
            console.log('Form submitted:', { email, password });
        }
    };

    if (!isOpen) return null;

    return (
        <div ref={ref} className="modal">
            <div className="modal-content">
                <div className="modal-header">
                    <h2>{isLogin ? 'Welcome back' : 'Create your account'}</h2>
                    <span className="close" onClick={onClose}>&times;</span>
                </div>
                <form onSubmit={handleSubmit}>
                    <label htmlFor="email">Email address*</label>
                    <input
                        type="text"
                        id="email"
                        name="email"
                        placeholder='Email Address'
                        value={email}
                        onChange={handleEmailChange}
                        required
                    />
                    {emailError && <div className="error">{emailError}</div>}
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder='Password'
                        value={password}
                        onChange={handlePasswordChange}
                        required
                    />
                    {passwordError && <div className="error">{passwordError}</div>}
                    <button type="submit" className="continue-button">Continue</button>
                    {isLogin ? (
                        <button type="button" onClick={() => setIsLogin(false)} className="toggle-button">Don't have an account? Sign up</button>
                    ) : (
                        <button type="button" onClick={() => setIsLogin(true)} className="toggle-button">Already have an account? Log in</button>
                    )}
                    <div className="or-divider">
                        <span>OR</span>
                    </div>
                    <button type="button" className="social-button google-button">
                        <img src={googleLogo} alt="Google logo" className="social-logo" /> Continue with Google
                    </button>
                    <button type="button" className="social-button microsoft-button">
                        <img src={microsoftLogo} alt="Microsoft logo" className="social-logo" /> Continue with Microsoft Account
                    </button>
                    <button type="button" className="social-button apple-button">
                        <img src={appleLogo} alt="Apple logo" className="social-logo" /> Continue with Apple
                    </button>
                </form>
            </div>
        </div>
    );
});

export default AuthModal;
