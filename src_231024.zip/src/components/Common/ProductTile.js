import React from 'react';
import '../../styles/ProductTile.css';

const ProductTile = ({ image, name, price, onAddToCart, onBuyNow }) => {
    return (
        <div className="product-tile">
            <img src={image} alt={name} className="product-tile__image" />
            <h4 className="product-tile__name">{name}</h4>
            <p className="product-tile__price">${price}</p>
            <div className="product-tile__actions">
                <button className="product-tile__button" onClick={onAddToCart}>Add to Cart</button>
                <button className="product-tile__button product-tile__button--buy" onClick={onBuyNow}>Buy Now</button>
            </div>
        </div>
    );
};

export default ProductTile;
