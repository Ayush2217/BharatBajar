// src/components/ProductCard.js
import React from 'react';
import PropTypes from 'prop-types';
import '../../styles/ProductCard.css';

const ProductCard = ({ productName, productImage, productPrice, onAddToCart, onBuyNow }) => {
    return (
        <div className="product-card">
            <img src={productImage} alt={productName} className="product-image" />
            <div className="product-info">
                <h3 className="product-name">{productName}</h3>
                <p className="product-price">${productPrice}</p>
                <div className="button-container">
                    <button className="add-to-cart-btn" onClick={onAddToCart}>Add to Cart</button>
                    <button className="buy-now-btn" onClick={onBuyNow}>Buy Now</button>
                </div>
            </div>
        </div>
    );
};

ProductCard.propTypes = {
    productName: PropTypes.string.isRequired,
    productImage: PropTypes.string.isRequired,
    productPrice: PropTypes.number.isRequired,
    onAddToCart: PropTypes.func.isRequired,
    onBuyNow: PropTypes.func.isRequired,
};

export default ProductCard;
