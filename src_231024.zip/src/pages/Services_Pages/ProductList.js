// src/components/ProductList.js
import React from 'react';
import PropTypes from 'prop-types';
import ProductCard from './ProductCard';
import '../../styles/ProductList.css';

const ProductList = ({ products, onAddToCart }) => {
    return (
        <div className="product-list">
            {products.map((product, index) => (
                <ProductCard
                    key={index}
                    productName={product.name}
                    productImage={product.image}
                    productPrice={product.price}
                    onAddToCart={() => onAddToCart(product)}
                />
            ))}
        </div>
    );
};

ProductList.propTypes = {
    products: PropTypes.arrayOf(
        PropTypes.shape({
            name: PropTypes.string.isRequired,
            image: PropTypes.string.isRequired,
            price: PropTypes.number.isRequired,
        })
    ).isRequired,
    onAddToCart: PropTypes.func.isRequired,
};

export default ProductList;
