// src/pages/Sales.js
import React, { useState } from 'react';
import SectionHeader from '../../components/Common/SectionHeader';
import Tile from '../../components/Common/Tile';
import ProductTile from '../../components/Common/ProductTile';
import AccessoriesSection from '../../components/ProductSections/AccessoriesSection';
import DealsSection from '../../components/ProductSections/DealsSection';
import EngagementSection from '../../components/ProductSections/EngagementSection';
import PersonalizedSection from '../../components/ProductSections/PersonalizedSection';
import useFetchProducts from '../../hooks/useFetchProducts';
import useModal from '../../hooks/useModal';
import useForm from '../../hooks/useForm';
import '../../styles/SalesPage.css';
import '../../styles/RepairProtectionPage.css'; // Importing RepairProtectionPage styles

// Importing default images for categories and products
import NewMobileImage from '../../assets/NewMobile.jpeg';
import RefurbishedImage from '../../assets/Refurbished.jpeg';
import RepairImage from '../../assets/Repair.png';
import AudioImage from '../../assets/learn.jpeg';

const SalesPage = () => {
    const categories = [
        { id: 1, name: 'Smartphones', image: NewMobileImage },
        { id: 2, name: 'Laptops', image: RefurbishedImage },
        { id: 3, name: 'Tablets', image: RepairImage },
        { id: 4, name: 'Audio & Accessories', image: AudioImage },
    ];

    // Fetch products using the custom hook
    const { data: products, isLoading, error } = useFetchProducts();

    const engagementItems = [
        { title: 'Top Rated Devices', description: 'Check out devices highly rated by our community.', image: RefurbishedImage },
        { title: 'Customer Favorites', description: 'Our customers love these products.', image: NewMobileImage },
    ];

    const personalizedItems = [
        { title: 'Samsung Galaxy S22', price: 799, image: NewMobileImage },
        { title: 'Sony WH-1000XM4', price: 349, image: AudioImage },
    ];

    const accessoriesItems = [
        { title: 'USB-C Charger', price: 29, image: RepairImage },
        { title: 'Screen Protector', price: 15, image: AudioImage },
    ];

    const dealsItems = [
        { title: 'Flash Deal - 50% Off', price: 499, image: NewMobileImage },
        { title: 'Limited Offer - Laptops', price: 799, image: RefurbishedImage },
    ];

    const repairItems = [
        { title: 'Device Diagnostic Tool', description: 'Check your device health with our diagnostic tool.', image: RepairImage },
        { title: 'Screen Replacement', description: 'Replace broken screens with our repair services.', image: RefurbishedImage },
        { title: 'Protection Plan', description: 'Get a protection plan for your valuable devices.', image: NewMobileImage },
    ];

    const [selectedCategory, setSelectedCategory] = useState(null);

    // Use modal hook to manage add-to-cart modal visibility
    const { isModalOpen, openModal, closeModal } = useModal();

    // Use form hook to manage purchase details form with initial values
    const { values, handleChange, handleSubmit } = useForm(
        { quantity: 1 }, // Initializing with default values
        () => {
            console.log('Form Submitted:', values);
            closeModal();
        }
    );

    const handleCategoryClick = (categoryName) => {
        setSelectedCategory(categoryName);
    };

    const handleAddToCart = (product) => {
        console.log(`Added to cart: ${product.name}`);
        openModal(); // Open modal to confirm addition
    };

    const handleBuyNow = (product) => {
        console.log(`Buying now: ${product.name}`);
    };

    return (
        <div className="sales-page">
            <SectionHeader title="Sales" subtitle="Explore our curated selection of cutting-edge electronic devices." />

            <div className="categories-section">
                {!selectedCategory &&
                    categories.map((category) => (
                        <Tile
                            key={category.id}
                            image={category.image}
                            title={category.name}
                            onClick={() => handleCategoryClick(category.name)}
                        />
                    ))}
            </div>

            <div className="products-section">
                {isLoading && <p>Loading products...</p>}
                {error && <p>Error loading products: {error}</p>}
                {selectedCategory && products && products[selectedCategory] && (
                    <>
                        <SectionHeader title={selectedCategory} />
                        <button className="back-button" onClick={() => setSelectedCategory(null)}>
                            Back to Categories
                        </button>
                        <div className="product-list">
                            {products[selectedCategory].map((product, index) => (
                                <ProductTile
                                    key={index}
                                    image={product.image}
                                    name={product.name}
                                    price={product.price}
                                    onAddToCart={() => handleAddToCart(product)}
                                    onBuyNow={() => handleBuyNow(product)}
                                />
                            ))}
                        </div>
                    </>
                )}
            </div>

            {/* Adding Product Sections */}
            <DealsSection dealsItems={dealsItems || []} />
            <AccessoriesSection accessoriesItems={accessoriesItems || []} />
            <EngagementSection communityItems={engagementItems || []} />
            <PersonalizedSection personalizedItems={personalizedItems || []} />

            {/* Repair & Protection Section - Added Below Deals Section */}
            <SectionHeader title="Repair & Protection" subtitle="Get diagnostics, repairs, and protection plans for your devices." />
            <div className="repair-protection-section">
                {repairItems.map((item, index) => (
                    <div key={index} className="repair-card">
                        <img src={item.image} alt={item.title} />
                        <h3>{item.title}</h3>
                        <p>{item.description}</p>
                        <button className="action-button">Learn More</button>
                    </div>
                ))}
            </div>

            {/* Modal for add to cart confirmation */}
            {isModalOpen && (
                <div className="modal">
                    <div className="modal-content">
                        <h3>Add to Cart</h3>
                        <form onSubmit={handleSubmit}>
                            <label>
                                Quantity:
                                <input
                                    type="number"
                                    name="quantity"
                                    value={values.quantity}
                                    onChange={handleChange}
                                    min="1"
                                />
                            </label>
                            <button type="submit">Confirm</button>
                            <button type="button" onClick={closeModal}>
                                Cancel
                            </button>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default SalesPage;
