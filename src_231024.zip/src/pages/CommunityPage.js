import React from 'react';
import '../styles/CommunityPage.css'; // Link to the CSS file

const CommunityPage = () => {
  return (
    <div className="community-page">
      {/* Header Section */}
      <section className="community-header">
        <h1>Welcome to the Device Mantra Community</h1>
        <p>Share your experiences, engage with others, and earn rewards!</p>
		<button className="cta-button" onClick={() => window.location.href = '/explore'}>
              Back To Exploring Devices
         </button>
        <button className="cta-button">Upload Your Content</button>
      </section>

      {/* Content Grid Section */}
      <section className="community-content-grid">
        <h2>Trending in the Community</h2>
        <div className="content-grid">
          {/* Example user-generated content */}
          <div className="content-tile">
            <h3>Unboxing Video</h3>
            <p>User: TechGuru</p>
          </div>
          <div className="content-tile">
            <h3>Review: iPhone 13</h3>
            <p>User: JaneDoe</p>
          </div>
          <div className="content-tile">
            <h3>How to Fix Screen Damage</h3>
            <p>User: FixItPro</p>
          </div>
        </div>
      </section>

      {/* Discussion Forum Section */}
      <section className="discussion-forum">
        <h2>Join the Conversation</h2>
        <p>Ask questions, share advice, and connect with other tech enthusiasts.</p>
        <div className="forum-grid">
          <div className="forum-post">
            <h4>Best tips for phone maintenance?</h4>
            <p>Posted by: GadgetLover</p>
          </div>
          <div className="forum-post">
            <h4>Need help with a battery issue</h4>
            <p>Posted by: JohnDoe</p>
          </div>
        </div>
        <button className="cta-button">Join a Discussion</button>
      </section>
    </div>
  );
};

export default CommunityPage;
