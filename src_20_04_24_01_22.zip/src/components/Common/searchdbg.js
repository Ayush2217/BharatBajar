import algoliasearch from "algoliasearch";

const searchClient = algoliasearch(
            "8MRLOZ7A26", // Your Algolia App ID
            "489c1269a1685a0990ecf6569113b29c" // Your Algolia API Key
        );


