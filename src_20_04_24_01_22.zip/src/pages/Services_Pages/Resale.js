// src/pages/Resale.js
import React from 'react';

const Resale = () => {
    return (
        <div className="resale-page">
            <h2>Resale</h2>
            <p>Sell your pre-owned devices on our secure platform.</p>
            {/* Add more content as needed */}
        </div>
    );
};

export default Resale;
