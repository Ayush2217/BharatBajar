// src/pages/Research_Pages/Sustainability.js
import React from 'react';

const Sustainability = () => {
    return (
        <div className="sustainability-page">
            <h2>Sustainability Research</h2>
            <p>Explore our research in Sustainability...</p>
            {/* Add more content as needed */}
        </div>
    );
};

export default Sustainability;
